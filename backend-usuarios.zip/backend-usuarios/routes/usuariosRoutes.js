import express from "express";
import { pool } from "../db.js";

const router = express.Router();

// Crear usuario
router.post("/usuarios", async (req, res) => {
  try {
    const { nombre, correo, contraseña } = req.body;
    const query = "INSERT INTO usuarios (nombre, correo, contraseña) VALUES ($1, $2, $3) RETURNING *";
    const values = [nombre, correo, contraseña];
    const result = await pool.query(query, values);
    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error al registrar el usuario" });
  }
});

// Listar usuarios
router.get("/usuarios", async (req, res) => {
  try {
    const result = await pool.query("SELECT * FROM usuarios");
    res.json(result.rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error al obtener los usuarios" });
  }
});

export default router;
